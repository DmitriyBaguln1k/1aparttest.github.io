// Группы объектов
var groups = [
        {
            name: "",
            style: "islands#redIcon",
            items: [
                {
                    center: [56.496090, 84.968427],
					zoom: 13
                   // name: "Монумент &quot;Родина-Мать&quot;"
                }
            ]}
        
    ];